This folder is mainly for Solidity libraries.
