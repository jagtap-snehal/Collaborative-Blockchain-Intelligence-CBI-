hot_dog.jpg
from Bing via many sites such as https://www.shutterstock.com/image-photo/hot-dog-ketchup-mustard-on-white-1050709127
