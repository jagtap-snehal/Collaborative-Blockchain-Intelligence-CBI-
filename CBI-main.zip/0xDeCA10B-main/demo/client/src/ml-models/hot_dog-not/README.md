# Train the Classifier
1. Download the data from [Kaggle](https://www.kaggle.com/dansbecker/hot-dog-not-hot-dog).
2. Extract the zipped package to this folder so that this folder has `seefood/train`, `seefood/test` in it.
3. From the `client` folder `yarn train-hot-dog-classifier`.
