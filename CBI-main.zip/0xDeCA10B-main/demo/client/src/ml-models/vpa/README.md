# Train the Classifier
From the `client` folder:
1. `git clone https://github.com/snipsco/nlu-benchmark ../../../nlu-benchmark`
2. Run `yarn train-vpa-classifier`
