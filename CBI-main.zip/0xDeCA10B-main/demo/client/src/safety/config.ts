export default {
	verified:
		[
			{
				// Example
				network: 'private',
				address: '0x1b88938102bE9ED97a0e9b8Cb321dD89C60e86Ab'
			},
		]
}
