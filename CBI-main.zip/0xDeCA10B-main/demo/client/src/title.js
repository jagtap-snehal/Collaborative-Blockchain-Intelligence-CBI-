export const BASE_TITLE = "Sharing Updatable Models (SUM)"
